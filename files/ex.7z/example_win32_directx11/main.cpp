// Dear ImGui: standalone example application for DirectX 11

// Learn about Dear ImGui:
// - FAQ                  https://dearimgui.com/faq
// - Getting Started      https://dearimgui.com/getting-started
// - Documentation        https://dearimgui.com/docs (same as your local docs/ folder).
// - Introduction, links and more at the top of imgui.cpp

#include "imgui.h"
#include "imgui_impl_win32.h"
#include "imgui_impl_dx11.h"
#include <d3d11.h>
#include <tchar.h>
#include <random>
#include <string>
#include <algorithm>
#include "resource.h"

#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"


// Data
static ID3D11Device*            g_pd3dDevice = nullptr;
static ID3D11DeviceContext*     g_pd3dDeviceContext = nullptr;
static IDXGISwapChain*          g_pSwapChain = nullptr;
static bool                     g_SwapChainOccluded = false;
static UINT                     g_ResizeWidth = 0, g_ResizeHeight = 0;
static ID3D11RenderTargetView*  g_mainRenderTargetView = nullptr;

// Forward declarations of helper functions
bool CreateDeviceD3D(HWND hWnd);
void CleanupDeviceD3D();
void CreateRenderTarget();
void CleanupRenderTarget();
LRESULT WINAPI WndProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam);

bool updatePlots = true;

ID3D11ShaderResourceView* g_TextureIcon1 = nullptr;
ID3D11ShaderResourceView* g_TextureIcon2 = nullptr;

float GetNewValue(float min, float max) {
    static std::default_random_engine engine(std::random_device{}());
    static std::uniform_real_distribution<float> dist(min, max);
    return dist(engine);
}
void addRealTimePlot(char * name, int i, float cellWidth)
{
    static float values[120] = {};
    static int values_offset = 0;

    ImGui::Text(name);
    ImGui::PushID(i);
    ImGui::PlotLines("##Scrolling",
        values, IM_ARRAYSIZE(values), values_offset,
        nullptr, -1.0f, 1.0f, ImVec2(cellWidth, 80));
    ImGui::PopID();
    // Update data
    if (updatePlots)
    {
        values[values_offset] = GetNewValue(-10, 10); // Replace with your real-time value
        values_offset = (values_offset + 1) % IM_ARRAYSIZE(values);
    }
}

bool LoadTextureFromFile(const char* filename, ID3D11ShaderResourceView** out_srv, ImVec2& out_size)
{
    int width, height, channels;
    unsigned char* image_data = stbi_load(filename, &width, &height, &channels, 4);
    if (!image_data)
        return false;

    D3D11_TEXTURE2D_DESC desc = {};
    desc.Width = width;
    desc.Height = height;
    desc.MipLevels = 1;
    desc.ArraySize = 1;
    desc.Format = DXGI_FORMAT_R8G8B8A8_UNORM;
    desc.SampleDesc.Count = 1;
    desc.Usage = D3D11_USAGE_DEFAULT;
    desc.BindFlags = D3D11_BIND_SHADER_RESOURCE;

    D3D11_SUBRESOURCE_DATA initData = {};
    initData.pSysMem = image_data;
    initData.SysMemPitch = width * 4;

    ID3D11Texture2D* texture = nullptr;
    if (FAILED(g_pd3dDevice->CreateTexture2D(&desc, &initData, &texture))) {
        stbi_image_free(image_data);
        return false;
    }

    D3D11_SHADER_RESOURCE_VIEW_DESC srvDesc = {};
    srvDesc.Format = desc.Format;
    srvDesc.ViewDimension = D3D11_SRV_DIMENSION_TEXTURE2D;
    srvDesc.Texture2D.MipLevels = 1;

    if (FAILED(g_pd3dDevice->CreateShaderResourceView(texture, &srvDesc, out_srv))) {
        texture->Release();
        stbi_image_free(image_data);
        return false;
    }

    texture->Release();
    stbi_image_free(image_data);
    out_size = ImVec2((float)width, (float)height);
    return true;
}

void buildToolbar()
{
    ImGuiStyle& style = ImGui::GetStyle();
    style.FramePadding.y = 14.0f; // Default is ~4.0f
    if (ImGui::BeginMainMenuBar())
    {

#if 1
        ImGui::BeginGroup();
        if (ImGui::ImageButton("##btn", (ImTextureID)g_TextureIcon1, ImVec2(32, 32)))
        {
            printf("ImageButton clicked!\n");
            //MessageBoxA(nullptr, "Icon clicked!", "Info", MB_OK);
        }
        if (ImGui::IsItemHovered())
        {
            ImGui::SetTooltip("Open File (Ctrl+O)");
        }
        ImGui::Text("Open1");
        ImGui::EndGroup();
#endif
        ImGui::Image((ImTextureID)g_TextureIcon2, ImVec2(64, 64));
        if (ImGui::MenuItem("Open", "Ctrl+O")) // "Open"
            printf("open clicked!\n");
        ImGui::EndMainMenuBar();
    }
    style.FramePadding.y = 4.0f; // Default is ~4.0f

}
// Main code
int main(int, char**)
{
#pragma region INIT0



    // Make process DPI aware and obtain main monitor scale
    ImGui_ImplWin32_EnableDpiAwareness();
    float main_scale = ImGui_ImplWin32_GetDpiScaleForMonitor(::MonitorFromPoint(POINT{ 0, 0 }, MONITOR_DEFAULTTOPRIMARY));

    // Create application window
    WNDCLASSEXW wc = { sizeof(wc), CS_CLASSDC, WndProc, 0L, 0L, GetModuleHandle(nullptr),
        LoadIconW(GetModuleHandle(nullptr), MAKEINTRESOURCEW(IDI_ICON1)),
        LoadCursorW(nullptr, IDC_ARROW),
        nullptr,
        nullptr,
        L"ImGui Example",
        LoadIconW(GetModuleHandle(nullptr), MAKEINTRESOURCEW(IDI_ICON1)) };
    ::RegisterClassExW(&wc);
    HWND hwnd = ::CreateWindowW(wc.lpszClassName, L"Dear ImGui DirectX11 Example", WS_OVERLAPPEDWINDOW, 100, 100, (int)(1280 * main_scale), (int)(800 * main_scale), nullptr, nullptr, wc.hInstance, nullptr);

    // Initialize Direct3D
    if (!CreateDeviceD3D(hwnd))
    {
        CleanupDeviceD3D();
        ::UnregisterClassW(wc.lpszClassName, wc.hInstance);
        return 1;
    }



    // Show the window
    ::ShowWindow(hwnd, SW_SHOWDEFAULT);
    ::UpdateWindow(hwnd);

    // Setup Dear ImGui context
    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    ImGuiIO& io = ImGui::GetIO(); (void)io;
    io.ConfigFlags |= ImGuiConfigFlags_NavEnableKeyboard;     // Enable Keyboard Controls
 //   io.ConfigFlags |= ImGuiConfigFlags_NavEnableGamepad;      // Enable Gamepad Controls

    // Setup Dear ImGui style
    ImGui::StyleColorsDark();
    //ImGui::StyleColorsLight();

    // Setup scaling
    ImGuiStyle& style = ImGui::GetStyle();
    style.ScaleAllSizes(main_scale);        // Bake a fixed style scale. (until we have a solution for dynamic style scaling, changing this requires resetting Style + calling this again)
    style.FontScaleDpi = main_scale;        // Set initial font scale. (using io.ConfigDpiScaleFonts=true makes this unnecessary. We leave both here for documentation purpose)

    // Setup Platform/Renderer backends
    ImGui_ImplWin32_Init(hwnd);
    ImGui_ImplDX11_Init(g_pd3dDevice, g_pd3dDeviceContext);

    // Load Fonts
    // - If no fonts are loaded, dear imgui will use the default font. You can also load multiple fonts and use ImGui::PushFont()/PopFont() to select them.
    // - AddFontFromFileTTF() will return the ImFont* so you can store it if you need to select the font among multiple.
    // - If the file cannot be loaded, the function will return a nullptr. Please handle those errors in your application (e.g. use an assertion, or display an error and quit).
    // - Use '#define IMGUI_ENABLE_FREETYPE' in your imconfig file to use Freetype for higher quality font rendering.
    // - Read 'docs/FONTS.md' for more instructions and details.
    // - Remember that in C/C++ if you want to include a backslash \ in a string literal you need to write a double backslash \\ !
    //style.FontSizeBase = 20.0f;
    //io.Fonts->AddFontDefault();
    //io.Fonts->AddFontFromFileTTF("c:\\Windows\\Fonts\\segoeui.ttf");
    //io.Fonts->AddFontFromFileTTF("../../misc/fonts/DroidSans.ttf");
    //io.Fonts->AddFontFromFileTTF("../../misc/fonts/Roboto-Medium.ttf");
    //io.Fonts->AddFontFromFileTTF("../../misc/fonts/Cousine-Regular.ttf");
    //ImFont* font = io.Fonts->AddFontFromFileTTF("c:\\Windows\\Fonts\\ArialUni.ttf");
    //IM_ASSERT(font != nullptr);
#pragma endregion
    // Our state
    bool show_demo_window = true;
    bool show_another_window = false;
    ImVec4 clear_color = ImVec4(0.45f, 0.55f, 0.60f, 1.00f);

    // Main loop
    bool done = false;

    ImVec2 iconSize;
    LoadTextureFromFile("GitHub_Guide.png", &g_TextureIcon1, iconSize);
    LoadTextureFromFile("docker.png", &g_TextureIcon2, iconSize);

    while (!done)
    {
#pragma region INIT

        // Poll and handle messages (inputs, window resize, etc.)
        // See the WndProc() function below for our to dispatch events to the Win32 backend.
        MSG msg;
        while (::PeekMessage(&msg, nullptr, 0U, 0U, PM_REMOVE))
        {
            ::TranslateMessage(&msg);
            ::DispatchMessage(&msg);
            if (msg.message == WM_QUIT)
                done = true;
        }
        if (done)
            break;

        // Handle window being minimized or screen locked
        if (g_SwapChainOccluded && g_pSwapChain->Present(0, DXGI_PRESENT_TEST) == DXGI_STATUS_OCCLUDED)
        {
            ::Sleep(10);
            continue;
        }
        g_SwapChainOccluded = false;

        // Handle window resize (we don't resize directly in the WM_SIZE handler)
        if (g_ResizeWidth != 0 && g_ResizeHeight != 0)
        {
            CleanupRenderTarget();
            g_pSwapChain->ResizeBuffers(0, g_ResizeWidth, g_ResizeHeight, DXGI_FORMAT_UNKNOWN, 0);
            g_ResizeWidth = g_ResizeHeight = 0;
            CreateRenderTarget();
        }

        // Start the Dear ImGui frame
        ImGui_ImplDX11_NewFrame();
        ImGui_ImplWin32_NewFrame();
        ImGui::NewFrame();
#pragma endregion
#if 1
        // 1. Show the big demo window (Most of the sample code is in ImGui::ShowDemoWindow()! You can browse its code to learn more about Dear ImGui!).
        if (show_demo_window)
            ImGui::ShowDemoWindow(&show_demo_window);
#endif
        // 2. Show a simple window that we create ourselves. We use a Begin/End pair to create a named window.
        {
            static float f = 0.0f;
            static int counter = 0;

            ImGuiViewport* viewport = ImGui::GetMainViewport();
            ImGui::SetNextWindowPos(viewport->WorkPos);
            ImGui::SetNextWindowSize(viewport->WorkSize);
            //ImGui::SetNextWindowViewport(viewport->ID);
            {
                static int  counter = 0;
                buildToolbar();

                ImGui::Begin("Hello, world!");                          // Create a window called "Hello, world!" and append into it.
                if (ImGui::BeginTabBar("MyTabBar")) {
#if 0
                    if (ImGui::BeginTabItem("Splitter")) {
                        // Initial sizes
                        static float left_width = 200.0f;
                        float splitter_thickness = 2.0f;
                        float min_panel_width = 50.0f;

                        // Full region size
                        ImVec2 content_avail = ImGui::GetContentRegionAvail();

                        // Adjust left and right width based on window size
                        left_width = max(left_width, min_panel_width);
                        left_width = min(left_width, content_avail.x - min_panel_width - splitter_thickness);
                        float right_width = content_avail.x - left_width - splitter_thickness;

                        // Left Panel
                        ImGui::BeginChild("LeftPanel", ImVec2(left_width, 0), true);
                        ImGui::Text("Left Panel");
                        ImGui::EndChild();

                        // Splitter (draggable)
                        ImGui::SameLine();
                        ImGui::InvisibleButton("Splitter", ImVec2(splitter_thickness, -1));
                        if (ImGui::IsItemActive())
                        {
                            left_width += ImGui::GetIO().MouseDelta.x;
                        }
                        ImGui::SameLine();

                        // Right Panel
                        ImGui::BeginChild("RightPanel", ImVec2(right_width, 0), true);
                        ImGui::Text("Right Panel");
                        ImGui::EndChild();

                        ImGui::EndTabItem();
                    }
#endif
                    if (ImGui::BeginTabItem("Tab2")) {
                        ImGui::Image((ImTextureID)g_TextureIcon2, ImVec2(64, 64));
                        ImGui::Text("Above child");

                        if (ImGui::BeginChild("Child1", ImVec2(600, 600), true))  // (ID, size, border)
                        {
                            ImGui::Text("This is inside the child window");
                            ImGui::Button("A button");
                        }
                        ImGui::EndChild();

                        ImGui::Text("Below child");

                        ImGui::EndTabItem();
                    }
                    if (ImGui::BeginTabItem("Plots"))
                    {
                        ImGui::Checkbox("Update Plots", &updatePlots);
#if 0
                        if (ImGui::CollapsingHeader("My Table Header", ImGuiTreeNodeFlags_DefaultOpen)) {
                            ImGui::Columns(3, nullptr, true); // 3 columns, resizable
                            for (int row = 0; row < 3; ++row) {
                                for (int col = 0; col < 3; ++col) {
                                    ImGui::Text("Row %d, Col %d", row, col);
                                    addRealTimePlot("Real-time Plot", 10 * row + col);
                                    ImGui::NextColumn();
                                }
                            }
                        }
                        // ...
                        ImGui::Columns(1); // End columns
#endif
#if 1
                        float cellWidth = -1;
                        int rows = 12;
                        int cols = 3;
                        if (ImGui::CollapsingHeader("My Table Header", ImGuiTreeNodeFlags_DefaultOpen)) {
                            if (ImGui::BeginTable("table", cols, ImGuiTableFlags_Borders)) {
                                float tableWidth = ImGui::GetContentRegionAvail().x;

                                ImGui::TableSetupColumn("Col 0"); // auto
                                ImGui::TableSetupColumn("Col 1"); // auto
                                ImGui::TableSetupColumn("Col 2", ImGuiTableColumnFlags_WidthFixed, tableWidth * 0.6f);  //% width

                                for (int row = 0; row < rows; ++row) {
                                    ImGui::TableNextRow();
                                    for (int col = 0; col < cols; ++col) {
                                        ImGui::TableSetColumnIndex(col);
                                        ImGui::Text("Cell %d,%d", row, col);
                                        addRealTimePlot("Real-time Plot", 10 * row + col, -1);

                                    }
                                }
                                ImGui::EndTable();
                            }
                        }
#endif
                        ImGui::EndTabItem();
                    }
                    if (ImGui::BeginTabItem("Misc"))
                    {
                        ImGui::Text("This is some useful text.");               // Display some text (you can use a format strings too)


                        //ImGui::SliderFloat("float", &f, 0.0f, 1.0f);            // Edit 1 float using a slider from 0.0f to 1.0f
                        //ImGui::ColorEdit3("clear color", (float*)&clear_color); // Edit 3 floats representing a color

                        if (ImGui::Button("Button"))                            // Buttons return true when clicked (most widgets return true when edited/activated)
                            counter++;
                        ImGui::SameLine();
                        ImGui::Text("counter = %d", counter);

                        ImGui::Text("Application average %.3f ms/frame (%.1f FPS)", 1000.0f / io.Framerate, io.Framerate);
                        ImGui::EndTabItem();
                    }

                    ImGui::EndTabBar();
                }


                ImGui::End();
            }
#if 0
        // 3. Show another simple window.
            if (show_another_window)
            {
                ImGui::Begin("Another Window", &show_another_window);   // Pass a pointer to our bool variable (the window will have a closing button that will clear the bool when clicked)
                ImGui::Text("Hello from another window!");
                if (ImGui::Button("Close Me"))
                    show_another_window = false;
                ImGui::End();
            }
#endif
        }
        // Rendering
        ImGui::Render();
        const float clear_color_with_alpha[4] = { clear_color.x * clear_color.w, clear_color.y * clear_color.w, clear_color.z * clear_color.w, clear_color.w };
        g_pd3dDeviceContext->OMSetRenderTargets(1, &g_mainRenderTargetView, nullptr);
        g_pd3dDeviceContext->ClearRenderTargetView(g_mainRenderTargetView, clear_color_with_alpha);
        ImGui_ImplDX11_RenderDrawData(ImGui::GetDrawData());

        // Present
        HRESULT hr = g_pSwapChain->Present(1, 0);   // Present with vsync
        //HRESULT hr = g_pSwapChain->Present(0, 0); // Present without vsync
        g_SwapChainOccluded = (hr == DXGI_STATUS_OCCLUDED);
    }

    // Cleanup
    ImGui_ImplDX11_Shutdown();
    ImGui_ImplWin32_Shutdown();
    ImGui::DestroyContext();

    CleanupDeviceD3D();
    ::DestroyWindow(hwnd);
    ::UnregisterClassW(wc.lpszClassName, wc.hInstance);

    return 0;
}

// Helper functions

bool CreateDeviceD3D(HWND hWnd)
{
    // Setup swap chain
    DXGI_SWAP_CHAIN_DESC sd;
    ZeroMemory(&sd, sizeof(sd));
    sd.BufferCount = 2;
    sd.BufferDesc.Width = 0;
    sd.BufferDesc.Height = 0;
    sd.BufferDesc.Format = DXGI_FORMAT_R8G8B8A8_UNORM;
    sd.BufferDesc.RefreshRate.Numerator = 60;
    sd.BufferDesc.RefreshRate.Denominator = 1;
    sd.Flags = DXGI_SWAP_CHAIN_FLAG_ALLOW_MODE_SWITCH;
    sd.BufferUsage = DXGI_USAGE_RENDER_TARGET_OUTPUT;
    sd.OutputWindow = hWnd;
    sd.SampleDesc.Count = 1;
    sd.SampleDesc.Quality = 0;
    sd.Windowed = TRUE;
    sd.SwapEffect = DXGI_SWAP_EFFECT_DISCARD;

    UINT createDeviceFlags = 0;
    //createDeviceFlags |= D3D11_CREATE_DEVICE_DEBUG;
    D3D_FEATURE_LEVEL featureLevel;
    const D3D_FEATURE_LEVEL featureLevelArray[2] = { D3D_FEATURE_LEVEL_11_0, D3D_FEATURE_LEVEL_10_0, };
    HRESULT res = D3D11CreateDeviceAndSwapChain(nullptr, D3D_DRIVER_TYPE_HARDWARE, nullptr, createDeviceFlags, featureLevelArray, 2, D3D11_SDK_VERSION, &sd, &g_pSwapChain, &g_pd3dDevice, &featureLevel, &g_pd3dDeviceContext);
    if (res == DXGI_ERROR_UNSUPPORTED) // Try high-performance WARP software driver if hardware is not available.
        res = D3D11CreateDeviceAndSwapChain(nullptr, D3D_DRIVER_TYPE_WARP, nullptr, createDeviceFlags, featureLevelArray, 2, D3D11_SDK_VERSION, &sd, &g_pSwapChain, &g_pd3dDevice, &featureLevel, &g_pd3dDeviceContext);
    if (res != S_OK)
        return false;

    CreateRenderTarget();
    return true;
}

void CleanupDeviceD3D()
{
    CleanupRenderTarget();
    if (g_pSwapChain) { g_pSwapChain->Release(); g_pSwapChain = nullptr; }
    if (g_pd3dDeviceContext) { g_pd3dDeviceContext->Release(); g_pd3dDeviceContext = nullptr; }
    if (g_pd3dDevice) { g_pd3dDevice->Release(); g_pd3dDevice = nullptr; }
}

void CreateRenderTarget()
{
    ID3D11Texture2D* pBackBuffer;
    g_pSwapChain->GetBuffer(0, IID_PPV_ARGS(&pBackBuffer));
    g_pd3dDevice->CreateRenderTargetView(pBackBuffer, nullptr, &g_mainRenderTargetView);
    pBackBuffer->Release();
}

void CleanupRenderTarget()
{
    if (g_mainRenderTargetView) { g_mainRenderTargetView->Release(); g_mainRenderTargetView = nullptr; }
}

// Forward declare message handler from imgui_impl_win32.cpp
extern IMGUI_IMPL_API LRESULT ImGui_ImplWin32_WndProcHandler(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam);

// Win32 message handler
// You can read the io.WantCaptureMouse, io.WantCaptureKeyboard flags to tell if dear imgui wants to use your inputs.
// - When io.WantCaptureMouse is true, do not dispatch mouse input data to your main application, or clear/overwrite your copy of the mouse data.
// - When io.WantCaptureKeyboard is true, do not dispatch keyboard input data to your main application, or clear/overwrite your copy of the keyboard data.
// Generally you may always pass all inputs to dear imgui, and hide them from your application based on those two flags.
LRESULT WINAPI WndProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
    if (ImGui_ImplWin32_WndProcHandler(hWnd, msg, wParam, lParam))
        return true;

    switch (msg)
    {
    case WM_SIZE:
        if (wParam == SIZE_MINIMIZED)
            return 0;
        g_ResizeWidth = (UINT)LOWORD(lParam); // Queue resize
        g_ResizeHeight = (UINT)HIWORD(lParam);
        return 0;
    case WM_SYSCOMMAND:
        if ((wParam & 0xfff0) == SC_KEYMENU) // Disable ALT application menu
            return 0;
        break;
    case WM_DESTROY:
        ::PostQuitMessage(0);
        return 0;
    }
    return ::DefWindowProcW(hWnd, msg, wParam, lParam);
}
